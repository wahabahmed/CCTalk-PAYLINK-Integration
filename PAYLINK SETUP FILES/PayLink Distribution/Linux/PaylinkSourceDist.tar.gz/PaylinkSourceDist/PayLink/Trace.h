//---------------------------------------------------------------------------
// FILE    : 	Trace.h
// PURPOSE :	Prototype for function to output formatted strings
//		to the "catch trace" window
//---------------------------------------------------------------------------

void tracef(char * Format, ...) ;


