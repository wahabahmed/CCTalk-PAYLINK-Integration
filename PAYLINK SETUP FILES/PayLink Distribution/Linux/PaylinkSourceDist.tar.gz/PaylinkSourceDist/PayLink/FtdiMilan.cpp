/******************************************************

This handles all the detail of accessing the FTDI link.

The application merely deals in packets

*******************************************************/
#ifndef __linux__
 #include <vcl.h>
 #pragma hdrstop
#else
 #include <stdlib.h>
 #include <string.h>
 #include <time.h>
#endif
#include <stdarg.h>
#include "FtdiAccess.h" /* AES Ftdi Header */

extern bool ShowTraffic ;


/******************************************************************

Generalised formatted Diagnostics output function. It requires the
main program to provide DiagText(char* Line), a function that will
acceptr a null terminate string (with an assumed, but not present,
line end character)

******************************************************************/
void DiagPrintf(const char* Format, ...)
{
  char Buffer[2048] ;
  va_list ap ;
  va_start(ap, Format) ;

  vsprintf(Buffer, Format, ap) ;
  DiagText(Buffer) ;
  va_end(ap) ;
}





/***********************************************************************

SendBuffer - returns 0 if good, -1 if a problem

***********************************************************************/
int  FTDIMilan::SendBuffer(void)
{
  unsigned int   ToWrite = TxBufferIndex ;
#ifndef __linux__
  unsigned long  BytesWritten ;
  char*          TxPoint = TxBuffer ;
  unsigned long  RxQueue ;
  unsigned long  InTxQueue ;
  unsigned long  EventStatus ;
#else
  unsigned int   BytesWritten ;
  unsigned char*  TxPoint = TxBuffer ;
#endif

#ifndef __linux__
  // First, make sure he chip is OK (writes can hang!)
  ftStatus = FT_GetStatus(Port->ftHandle, &RxQueue, &InTxQueue, &EventStatus) ;
  if (!FT_SUCCESS(ftStatus))
  {
    DiagPrintf("Get Queue Status failed %d!", ftStatus) ;
    if (!Port->RecoverUSB())               // Sort out the FTDI chip
    {
      return false ;
    }
  }

  while (ToWrite != 0)
  {
    ftStatus = FT_Write(Port->ftHandle, TxPoint, ToWrite, &BytesWritten) ;
    while (!FT_SUCCESS(ftStatus))
    {
      DiagPrintf("Write failed %d!", ftStatus) ;
      if (Port->RecoverUSB())               // Sort out the FTDI chip
      {
        ftStatus = FT_Write(Port->ftHandle, TxPoint, ToWrite, &BytesWritten) ;
      }
      else
      {
        return false ;
      }
    }

    ToWrite -= BytesWritten ;
    TxPoint += BytesWritten ;
  }
#else
  if (Port->CheckUSBNowOK((char *)"") != true)
  {
    DiagPrintf("Check USB Status ** FAILED **!") ;
    if (!Port->RecoverUSB())
    {
        return false ;
    }
  }

  while (ToWrite != 0)
  {
    BytesWritten = ftdi_write_data(&Port->Ftdi, TxPoint, ToWrite);
    while (BytesWritten <= 0)
    {
      DiagPrintf("Write failed %d!", BytesWritten) ;
      if (Port->RecoverUSB())               // Sort out the FTDI chip
      {
        BytesWritten = ftdi_write_data(&Port->Ftdi, TxPoint, ToWrite);
      }
      else
      {
        return false ;
      }
    }

    ToWrite -= BytesWritten ;
    TxPoint += BytesWritten ;
  }
#endif
  TxBufferIndex = 0 ;             // Reset buffer
  return 0;
}






/***********************************************************************

QueuePacket

***********************************************************************/
void FTDIMilan::QueuePacket(unsigned short Address, int Value)
{
  if (ShowTraffic)
  {
    DiagPrintf(" -->%04x %08x", Address, Value) ;
  }

  short* pShort = (short*)&TxBuffer[TxBufferIndex] ;
  *pShort = Address ;
  TxBufferIndex += 2 ;

  int*  pint  =  (int*)&TxBuffer[TxBufferIndex] ;
  *pint  = Value ;
  TxBufferIndex += 4 ;

  if (TxBufferIndex > (short)(sizeof TxBuffer))
  {                   // Tihs can't happen !!!
    DiagPrintf(" ******   Buffer overflow ******") ;
    SendBuffer() ;
  }
}





/***********************************************************************

ResetTxBuffer

***********************************************************************/
void FTDIMilan::ResetTxBuffer(void)
{
  TxBufferIndex = 0 ;
}



/***********************************************************************

ProcessIncomingStream

***********************************************************************/

bool FTDIMilan::ProcessIncomingStream(void)
{
  static char           Packet[6] ;
  static unsigned short PacketIndex = 0 ;

#ifdef __linux__
  unsigned int          CharsInQueue = 0 ;
  static time_t         ReadTime    = 0 ;
  static int            Retries     = 0 ;

  if (Port->CheckUSBNowOK((char *)"") != true)
  {
    DiagPrintf("Check USB Status ** FAILED **!") ;
    if (!Port->RecoverUSB())
    {
        return false ;
    }
    CharsInQueue = 1;
  }else
     CharsInQueue = 1 ;

#else
  unsigned long         CharsInQueue = 0 ;
  ftStatus = FT_GetQueueStatus(Port->ftHandle, &CharsInQueue) ;
  if (!FT_SUCCESS(ftStatus))
  {
    DiagPrintf("Get Queue Status failed %d!", ftStatus) ;
    if (Port->RecoverUSB())               // Sort out the FTDI chip
    {
      ftStatus = FT_GetQueueStatus(Port->ftHandle, &CharsInQueue) ;
    }
    else
    {
      return false ;
    }
  }
#endif

  if (CharsInQueue)
  {
    unsigned char  RxBuffer[4096] ;
    if (CharsInQueue > sizeof RxBuffer)
    {
      CharsInQueue = sizeof RxBuffer ;
    }

#ifndef __linux__
    unsigned long  RxBufferRead ;
    ftStatus = FT_Read(Port->ftHandle, RxBuffer, CharsInQueue, &RxBufferRead);
    while (!FT_SUCCESS(ftStatus))
#else
    unsigned int   RxBufferRead ;
    RxBufferRead = ftdi_read_data( &Port->Ftdi, RxBuffer, sizeof RxBuffer );
    while (RxBufferRead < 0)
#endif
    {
      DiagPrintf("Read returned error status %d!", ftStatus) ;
      if (Port->RecoverUSB())               // Sort out the FTDI chip
      {
#ifndef __linux__
        ftStatus = FT_Read(Port->ftHandle, RxBuffer, CharsInQueue, &RxBufferRead);
#else
        RxBufferRead = ftdi_read_data( &Port->Ftdi, RxBuffer, CharsInQueue );
#endif
      }
      else
      {
        return false ;
      }
    }

    // Process the incomming data
    #ifdef __linux__
      ReadTime = time(NULL);
      Retries  = 0 ;
    #endif

    bool SyncSent = false ;

    for (unsigned int i = 0 ; i < RxBufferRead ; ++i)
    {
      if (PacketIndex == 0 && RxBuffer[i] == 0xff)
      {
        // Skip Sync characters
        if (!SyncSent)
        {                   // If the remote system has resynched
          QueuePacket(-1 , -1) ; // Then we will too!
          SyncSent = true ;
        }
      }
      else
      {
        Packet[PacketIndex] = RxBuffer[i] ;
        if (++PacketIndex == 6)
        {           // Process the packet
          (*ProcessIncomingPacket)(*(short*)Packet, *(int*)&Packet[2]) ;
          PacketIndex = 0 ;
        }
      }
    }
  }
  #ifdef __linux__
    else
    {
      /*-- This is to prevent lock-ups on certain kernels (2.4 / 2.6) ---*/
      /*-- Unsure as what these kernels are doing but they seem to sit --*/
      /*-- calling this function endlessly (AESWDriver) !! --------------*/

      if (ReadTime && ((time(NULL) - ReadTime) >= 5))
      {
        DiagPrintf("PC: FT Read timeout (%d)", (time(NULL) - ReadTime));
        ReadTime = time(NULL);
        if (++Retries > 2)
        {
          return false;
        }
        Port->RecoverUSB() ;
      }
      usleep(1); /*-- Let the kernel scheduler kick in here -------------*/
    }
  #endif

  return true ;
}
