//-------------------------------------------------
//
// Global Data
//
//-------------------------------------------------
#include "PCStuff.h"            // The *contents* of this may vary in other projects!

enum
    {
    NotConnected,
    Pause,
    CheckingPC,
    CheckingUSB,
    Sending,
    Reading,
    DriverAbort
    } ;

extern          int     CurrentDriverState ;
extern          int     MemoryInterlock ;

extern unsigned int     DiagReadIndex ;

extern unsigned char*   Base ;
extern volatile int*    SharedMemoryBase ;      // This is the shared memory segment for the application
extern          int     Mirror[2048] ;          // This is what we know that the H8 knows about
extern          int     RecoveryMirror[2048] ;  // This is what the H8 tells us during a restart
extern PCInternalBlock* PCInternal ;

extern          int     LatencyParameter ;

extern          int     ReportedCardSelfTest ;

extern          char    DriverVersion[] ;
extern          char    ConfigFileStr[] ;

void StartDriverThread(void) ;
void StartDriverThread(char * SerialNumber);

void DiagPutChar(char TheChar) ;

bool CommunicateWithCard(void) ;

#ifndef __linux__
    extern HANDLE Timer ;
    extern HANDLE Mutex ;
#endif

// This function is part of the MCL USB support code. On Linux and PC Standalone it just need a null stub (it's not called)
bool MergeProcessInput(int Index, int Value) ;
int  MergeProcessOutput(int Index, int Value) ;

// Check that int is exactly 4 bytes - if it is not one of these will generate a compile fault
extern char CheckIntSize[sizeof (int) - 3] ;
extern char CheckIntSize2[5 - sizeof (int)] ;

