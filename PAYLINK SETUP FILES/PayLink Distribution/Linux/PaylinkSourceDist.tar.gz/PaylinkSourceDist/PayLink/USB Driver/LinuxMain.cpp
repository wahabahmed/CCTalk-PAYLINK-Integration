/*--------------------------------------------------------------------------*\
 * Application Version Define.
\*--------------------------------------------------------------------------*/
char DriverVersion[] = "1.2.0.1" ;

/*--------------------------------------------------------------------------*\
 * System Includes.
\*--------------------------------------------------------------------------*/
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sched.h>

/*--------------------------------------------------------------------------*\
 * Application Includes.
\*--------------------------------------------------------------------------*/
#include "DriverFuncs.h"

bool RunHidden ;
bool RunVisible ;
char*           Serial = 0 ;
char            LoggingFileName[256] ;
int             LogFileSize = 128 * 1024 ;
char            ConfigFileStr[256] = "Standard.cfg" ;
bool            ShowTraffic ;
int             LatencyParameter ;
bool            USBUsed ;



// In this build, these are null stubs to keep linker happy.
bool MergeProcessInput(int Index, int Value) {return false ;}
int  MergeProcessOutput(int Index, int Value) {return Value ;}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*\
 * Public Global Data.
\*--------------------------------------------------------------------------*/
struct itimerval Timer;

/*--------------------------------------------------------------------------*\
 * Local Data.
\*--------------------------------------------------------------------------*/
static pid_t   ComPid     = -1 ;
static pid_t   DiagPid    = -1 ;
static int     MMFile     = -1 ;


/*--------------------------------------------------------------------------*\
 * Externally declared functions.
\*--------------------------------------------------------------------------*/
extern bool CommunicateWithCard (void);
extern void DiagPutChar (char theChar);


/*--------------------------------------------------------------------------*\
 * AbortHandler:
 * -------------
 *
 *
 * Arguments:
 * ----------
 *
 * Return:
 * -------
 *
\*--------------------------------------------------------------------------*/
void
AbortHandler                            (int             signum)
{
    if (RunVisible)
    {
        if (DiagPid != 0 && ComPid  == 0)
        {
        DiagPrintf("Comms task signalled <%d> ... exiting", signum) ;
        }
        else
        {
        printf("Warning: Caught signal <%d> ... exiting [%s]\r\n", signum,
            (DiagPid == 0) ? "Diag" :
                             "Main") ;
        }
    }
    fflush(stdout) ;

    exit(0);
}


static pid_t  ChildPid = -1;
extern char  *GetTime            (void);

/*--------------------------------------------------------------------------*\
 * ShowTrafficHanlder:
 * -------------------
 *
 *
 * Arguments:
 * ----------
 *
 * Return:
 * -------
 *
\*--------------------------------------------------------------------------*/
void
ShowTrafficHanlder                      (int             signum)
{   if (ChildPid == getpid())
        ShowTraffic = !ShowTraffic;
}


/*--------------------------------------------------------------------------*\
 * ConfigErrorReport:
 * -------------------
 *
 *
 * Arguments:
 * ----------
 *
 * Return:
 * -------
 *
\*--------------------------------------------------------------------------*/
void ConfigErrorReport(char* Message)
{
    static bool PrintHead = true ;
    if (PrintHead)
    {
        PrintHead = false ;
        fprintf (stderr, "[AESCDriver] ERROR: problem with configuration file:\n") ;
    }
    fprintf (stderr, "        %s\n", Message) ;
}

/*--------------------------------------------------------------------------*\
 * DisplayHelpMessage:
 * -------------------
 *
 * Display a help message for the vi_test application.
 *
 * Arguments:
 * ----------
 * none.
 *
 * Returns:
 * --------
 * none.
 *
\*--------------------------------------------------------------------------*/
static int
DisplayHelpMessage                        (void)
{
    printf("AESCDriver [options] <Config File name>\n") ;
    printf("    - Aardvark Embedded Systems %s USB Driver Interface [v%s].\n", PRODUCT_NAME, DriverVersion);
    printf("    Options:\n");
    printf("      -?             Display this help message.     \n");
    printf("      -v             Show Diagnostic information.   \n");
    printf("      -t             Show Traffic to/from interface.\n");
    printf("      -p             Run at high priority.          \n");
    printf("      -s <Serial No> Communicate with given Paylink.\n");
    exit (EXIT_FAILURE);
}

char ShareName[32];
char SavedSerialNumber[12];


//---------------------------------------------------------------------------
void DriverProcess(void)
{
    /*-- Install signal handler to enable / disable ShowTraffic -------*/
    ChildPid = getpid();
    (void)signal(SIGUSR1, ShowTrafficHanlder);

    CurrentDriverState = NotConnected;

    if (!CommunicateWithCard ())
    {   CurrentDriverState = NotConnected;
        DiagPutChar('\f');
        DiagPrintf ("Retrying following failure....");
        Sleep (1000);
    }
    _exit(0);
}



//-----------------------------------------------------------------------------
static void GetDiags(void)
{
     // Pick up any staged diagnositcs
     int Logging = 0 ;
     int Result = 0 ;
     static bool FileError = true ;
     char Buffer[BUFFER_SIZE] ;
     unsigned int  BuffInd = 0 ;
     while ((long)(PCInternal->DiagWriteIndex & PCInternal->DiagIndexMask) !=
                         (long)(DiagReadIndex & PCInternal->DiagIndexMask))
        {
        char TheChar = PCInternal->DiagBuffer[DiagReadIndex++ & PCInternal->DiagIndexMask] ;
        if (TheChar == '\f')
            {
            BuffInd = 0 ;
            }

        if (TheChar != 0)
            {
            Buffer[BuffInd++] = TheChar ;
            }
        }


     // Dispose of any staged diagnositcs
    if (BuffInd)
        {     // Dispose of any staged diagnositcs
        if (LoggingFileName[0])
            {
            if (Logging == 0)
                {
                Logging = open(LoggingFileName,
                                O_RDWR | O_APPEND | O_CREAT,
                                S_IREAD | S_IWRITE) ;
                }
            if (Buffer[0] == '\f')
                {
                Result = write(Logging, "\n\n\n\n\n", 5) ;
                Result = write(Logging, Buffer + 1, BuffInd - 1) ;
                }
            else
                {
                Result = write(Logging, Buffer, BuffInd) ;
                }

           if ((Result < 0) && FileError)
                {
                FileError = false ;
                fprintf(stderr, "Error writing %s\n", LoggingFileName) ;
                }
            }


        if (RunVisible)
            {
            Buffer[BuffInd] = '\0' ;
            if (Buffer[0] == '\f')
                {
                printf("\n\n\n\n\n") ;
                puts(Buffer + 1) ;
                }
            else
                {
                puts(Buffer) ;
                }
            fflush(stdout) ;
            }
        Sleep(0) ;
        }

    if (Logging)
        {
        // Now check the size of the file - we don't wnat to let this get too big as we want to be
        // able to e-mail it!
        struct stat Details;
        fstat(Logging , &Details);

       if (Details.st_size > LogFileSize)
            {
            Result = write(Logging, "\r\nMaximum file size reached\r\n", 29) ;
            close(Logging) ;

            // Delete the old file
            char BackupFile[1024] ;
            strcpy(BackupFile, LoggingFileName) ;
            strcat(BackupFile, ".old") ;
            remove(BackupFile) ;

            // rename the current one
            rename(LoggingFileName, BackupFile) ;

            // and restart it
            Logging = open(LoggingFileName,
                           O_RDWR | O_CREAT | O_TRUNC,
                           S_IREAD | S_IWRITE) ;
            }

        close(Logging) ;
        }
}





/*--------------------------------------------------------------------------*\
 * main:
 * -----
 *
 *
 * Arguments:
 * ----------
 *
 * Return:
 * -------
 *
\*--------------------------------------------------------------------------*/
int
main (int argc, char *argv[])
{
    char         tmp[256]   = "";
    int          option     = -1;
    int          num        = -1;
    int          highpri    =  0;
    int          pagesize   = getpagesize();
    struct  sched_param  sched;

    /*-- Catch signals so we exit cleanly -----------------------------*/
    signal(SIGHUP,    AbortHandler);    signal(SIGINT,  AbortHandler);
    signal(SIGQUIT,   AbortHandler);    signal(SIGILL,  AbortHandler);
    signal(SIGTRAP,   AbortHandler);    signal(SIGABRT, AbortHandler);
    signal(SIGBUS,    AbortHandler);    signal(SIGFPE,  AbortHandler);
    signal(SIGKILL,   AbortHandler);    signal(SIGUSR1, SIG_IGN);
    signal(SIGSEGV,   AbortHandler);    signal(SIGUSR2, AbortHandler);
    signal(SIGPIPE,   AbortHandler);    signal(SIGALRM, AbortHandler);
    signal(SIGTERM,   AbortHandler);    /* SIGCHLD caught with waitpid */
    signal(SIGCONT,   AbortHandler);    signal(SIGSTOP, AbortHandler);
    signal(SIGTSTP,   AbortHandler);    signal(SIGTTIN, AbortHandler);
    signal(SIGTTOU,   AbortHandler);    signal(SIGURG,  AbortHandler);
    signal(SIGXCPU,   AbortHandler);    signal(SIGXFSZ, AbortHandler);
    signal(SIGVTALRM, AbortHandler);    signal(SIGPROF, AbortHandler);
    signal(SIGWINCH,  SIG_IGN);         signal(SIGIO,   AbortHandler);
    signal(SIGPWR,    AbortHandler);    signal(SIGSYS,  AbortHandler);


    /*-- Ensure this is being executed by the super user --------------*/
    if (getuid() != 0)
    {   fprintf (stderr, "[AESCDriver] ERROR: Application must be run as root [SuperUser]\r\n");
        fflush  (stderr);
        exit (EXIT_FAILURE);
    }

    /*-- Decode Command Line Arguments Supplied -----------------------*/
    while ((option=getopt(argc,argv,"?vtps:l:")) != -1)
    {   switch(option)
        { case 'v': RunVisible  = 1; break;
          case 't': ShowTraffic = 1; break;
          case 'p': highpri     = 1; break;
          case 's': Serial      = optarg ; break;
          case '?':
          default : DisplayHelpMessage();
        }
    }

    if (optind != argc)
    {
        strcpy(ConfigFileStr, argv[optind]) ;
    }
    printf("Configuration file: %s\n", ConfigFileStr) ;

    if (!ProcessConfig(ConfigFileStr))
    {                                           // We run a completely different "app", just to display the error
        fflush  (stderr);
        exit (EXIT_FAILURE);
    }


    /*-- Determine if a serial number has been given ------------------*/
    if (Serial != NULL)
    {
        strcpy(SavedSerialNumber, Serial) ;
        strcpy(ShareName, SHARED_NAME) ;
        if (SavedSerialNumber[0])
        {
            strcat(ShareName, SavedSerialNumber) ;
        }
    }
    else
    {
        strcpy(ShareName, SHARED_NAME) ;
    }



    /*-- Set up the shared Memory -------------------------------------*/
    MMFile = shm_open(ShareName, O_CREAT | O_RDWR,  0777 );
    if (MMFile == -1)
    {   fprintf (stderr, "[USBDriver] ERROR: Creating shared memory segment (shm_open).\r\n") ;
        fflush  (stderr);
        exit(0) ;
    }

    /*-- Ensure permissions are set correctly on the shared memory ----*/
    sprintf (tmp, "/dev/shm/%s", ShareName);
    chmod (tmp, 0777);

    /*-- Calculate number of pages required ---------------------------*/
    num = abs(((EXTENDED_SHARED_SIZE) / pagesize));
    if ((num * pagesize) < (EXTENDED_SHARED_SIZE))
        num+=1;

    if ((ftruncate (MMFile, (num * pagesize))) == -1)
    {   fprintf (stderr, "[USBDriver] ERROR: Creating shared memory segment (ftruncate).\r\n") ;
        fflush  (stderr);
        exit(0) ;
    }

    /*-- Set up the mirrors -------------------------------------------*/
    Base = (u_char *)mmap( 0, num*pagesize, PROT_READ | PROT_WRITE, MAP_SHARED, MMFile, 0);
    if (Base == (void *) -1)
    {   fprintf (stderr, "[USBDriver] ERROR: Creating shared memory segment (mmap).\r\n") ;
        fflush  (stderr);
        exit(0) ;
    }
    SharedMemoryBase = (int *)Base ;

    /*-- Driver (re)start - so reset everything! ----------------------*/
    memset ((void *)SharedMemoryBase, 0, 8192);
    memset ((void *)Mirror,           0, 8192);

    /*-- Set up the diagnostics ---------------------------------------*/
    PCInternal                = PC_INTERNAL_BLOCK (Base);
    PCInternal->DiagIndexMask = BUFFER_SIZE - 1;
    DiagReadIndex             = PCInternal->DiagWriteIndex;

    /*-- Increase Priority of Driver Process --------------------------*/
    if (highpri)
    {   if (!sched_getparam(0, &sched))
        {   sched.sched_priority = sched_get_priority_max (SCHED_RR) - 10;
            sched_setscheduler (0, SCHED_RR, &sched);
        }
    }

    /*-- Start diagnostic display process (if necessary)---------------*/
    if ((RunVisible || LoggingFileName[0]) && ((DiagPid = fork()) == 0))
    {
        while (true)
        {
            Sleep(20) ;
            GetDiags() ;
        }
    }

    /*-- Start communications process ---------------------------------*/
    /*-- This has to performed within a new process and not a thread --*/
    /*-- because the FT_Open function will continually report that   --*/
    /*-- no device is present if the device is pluged in after the   --*/
    /*-- the driver has been started !!!                             --*/
    while (true)
    {
        switch ((ComPid = fork()))
        { case  0:
            /*-- Attempt to locate the device and start comms with it -*/
            DriverProcess();
            printf("Driver Return\n") ;
            exit(0) ;
            break;

          case -1:
            fprintf (stderr, "[USBDriver] ERROR: Creating communication process.\r\n") ;
            fflush  (stderr);
            exit(0);

          default:
            /*-- Wait for the comms process to finish -----------------*/
            Sleep   (1000);
            waitpid (ComPid, 0, 0);
            break;
        }
        DiagPrintf("Process %d exited - restarting", ComPid) ;
        fflush(stdout) ;
    }
    return 0;
}
