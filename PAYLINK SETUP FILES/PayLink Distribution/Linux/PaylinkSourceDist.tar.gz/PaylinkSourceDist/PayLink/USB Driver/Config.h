/***********************************************************************

Milan Configuration System

************************************************************************/

// -------------------------------------
// Process input config files
// -------------------------------------

bool ProcessConfig(char* ConfigFile) ;

void ConfigErrorReport(char* Message) ;

//
//  The data structure used to hold Paylink configuration data
//
extern ConfigurationRecord TheConfig[255] ;
extern short ConCount ;


//
//  The data structure used to store USB devices locally
//

class Port ;

typedef struct
    {
    bool      CoinRecyc ;
    bool      LiteUnit ;
    int       VID ;
    int       PID ;
    int       BaudRate ;
    char*     Name ;
    char*     FullName ;

    char*     SerialDevice ;
    int       SerialCommNumber ;
    int       MaxLevel ;

    Port*     ThePort ;
    } USBSpec ;

extern USBSpec TheUSBSpec[] ;
extern short USBConfigCount ;
extern short LiteConfigCount ;

extern bool UsingDongle ;
extern bool MergedInterface ;
extern bool UsingLite ;
extern bool USBUsed ;


#define MCL_VID 0x106f       // MCL

