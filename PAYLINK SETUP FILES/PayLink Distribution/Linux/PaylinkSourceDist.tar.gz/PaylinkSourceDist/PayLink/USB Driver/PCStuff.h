#ifndef MAIN_HEADER
  #include "../Headers.h"
#endif
#include "../FtdiAccess.h" /* AES Ftdi Header */
#include "../../Configuration.h"
#include "Config.h"

// Data for Driver from Config system

#ifdef VCL_H
extern        AnsiString      Serial ;
extern        AnsiString      LoggingFileName ;
#else
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
extern        char*     Serial ;
extern        char      LoggingFileName[256] ;
#endif

extern        int             LogFileSize ;


extern        int             BCRComPort ;
