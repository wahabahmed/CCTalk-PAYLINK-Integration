#!/bin/sh
CPLUS_INCLUDE_PATH=/usr/lib/jvm/default-java/include
export CPLUS_INCLUDE_PATH
make so
