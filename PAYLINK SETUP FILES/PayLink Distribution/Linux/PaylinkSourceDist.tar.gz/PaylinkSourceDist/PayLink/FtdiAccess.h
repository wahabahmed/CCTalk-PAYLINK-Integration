/******************************************************

This handles all the detail of accessing the FTDI link.

The application merely deals in packets

*******************************************************/
#ifndef FTDI_ACCESS
#define FTDI_ACCESS


#include <stdio.h>
#ifndef __linux__
  #include "FTD2xx.h"
#else
  #include "ftdi.h"
#endif

//
// This class allows for arbitrary access to an FTDI chip.
//
class WinUSB ;

class FTDIAccess
    {
    bool        ftOpened ;

    char        ManufacturerBuf[32]   ;
    char        ManufacturerIdBuf[16] ;
    char        DescriptionBuf[64]    ;
    char        SerialNumberBuf[16]   ;

    int         ftDeviceSerialNumber ;
    unsigned long ftDevice ;
    char*       ftUSBSerial ;
    int         OpenCalls ;
    char        DeviceSerialNumber[12];

    char*       ProductName ;
    unsigned int Vid ;
    unsigned int Pid ;



    #ifndef __linux__
      int       BaudRateSetting ;
      int       BitsSetting ;
      int       StopSetting ;
      int       ParitySetting ;
      WinUSB*   USBFuncs ;
    #else
      int                 BaudRateSetting ;
      ftdi_bits_type      BitsSetting ;
      ftdi_stopbits_type  StopSetting ;
      ftdi_parity_type    ParitySetting ;
    #endif

    bool        CommonUSBOpen() ;

  public:
    #ifndef __linux__
      FT_PROGRAM_DATA     ftData ;
      FT_HANDLE           ftHandle ;
      FT_STATUS           ftStatus ;

    #else
      struct ftdi_context Ftdi ;
      int                 ftStatus ;
    #endif
    int         FtdiLatency ;

    bool        USBOpen() ;
    bool        USBOpenSpecific(char *Serial) ;
    bool        USBOpenNew(char* FullProductName, char* DefaultUSBSerialNumber) ;
    void        USBClose(void) ;
    bool        CheckUSBNowOK(char *) ;
    bool        RecoverUSB(void) ;
#ifndef __linux__
    bool SetPort(int BaudRate, int Bits, int Stop, int Parity) ;
#else
    bool SetPort(int BaudRate, ftdi_bits_type Bits, ftdi_stopbits_type Stop, ftdi_parity_type Parity) ;
#endif

    FTDIAccess(char* ProductName, int Vid, int Pid, int Baud) ;
    ~FTDIAccess() ;
    } ;



//
// This class allows for access using the above to a Paylink device
//
class FTDIMilan
    {
    FTDIAccess* Port ;                         // This is the related port
    #ifndef __linux__
      FT_STATUS           ftStatus ;
    #else
      int                 ftStatus ;
    #endif

    #ifndef __linux__
      char      TxBuffer[2048 * 6] ;              // an entry for each word in the shared ememory
    #else
      unsigned char TxBuffer[2048 * 6] ;     // an entry for each word in the shared ememory
    #endif
    short       TxBufferIndex ;

  public:
    void        QueuePacket(unsigned short Address, int Value) ;
    int         SendBuffer(void) ;
    void        ResetTxBuffer(void) ;
    bool        ProcessIncomingStream(void) ;                                  // This will call ProcessIncomingPacket as necessary
    void        (*ProcessIncomingPacket)(unsigned short Address, int Value) ;  // This is supplied by the application!
    FTDIMilan(FTDIAccess* Port)
        {
        this->Port = Port ;
        ftStatus = 0 ;
        TxBuffer[0] = 0 ;
        TxBufferIndex = 0 ;
        ProcessIncomingPacket = 0 ;
        }
    } ;


//-------------------------------------------------
// Diagnostics Support
//-------------------------------------------------

void  DiagPrintf(const char* Format, ...) ;
void  DiagText(char* Line) ;

// Check that int is exactly 4 bytes - if it is not one of these will generate a compile fault
extern char CheckIntSize[sizeof (int) - 3] ;
extern char CheckIntSize2[5 - sizeof (int)] ;


#endif
