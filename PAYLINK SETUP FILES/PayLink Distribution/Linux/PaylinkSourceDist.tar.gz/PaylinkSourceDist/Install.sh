#!/bin/bash
#-- lecho function shows [PASS]/[FAIL] at end of line ------------------------#
message=""
lecho()
{ chars=$(echo $message | wc -c)
  let "remChars=75 - $chars"
  spaces=""
  while [ "$remChars" -ne "2" ]
  do
    spaces="$spaces "
    let remChars=remChars-1
  done
  echo -n "$spaces"
  if [ $1 -ne 0 ]; then
    echo -en "[\033[1;31mFAIL\033[0m]\n"
  else
    echo -en "[\033[1;32mPASS\033[0m]\n"
  fi
}


#-----------------------------------------------------------------------------#
pd="$(pwd)"

#-----------------------------------------------------------------------------#
if [ $(id -u) != 0 ]; then
	echo -e "ERROR: Must be superuser (root) to run the Install script.\n"
	exit 1
fi
		

#-- Set up headers ---------------------------------------------#
message="  Copying win_types.h.....=>./usr/include/ ..."
echo -n $message
cp ./win_types.h      /usr/include/ 1>/dev/null 
lecho $?
message="  Copying ImheiEvent.h...=>./usr/include/ ..."
echo -n $message
cp ./ImheiEvent.h    /usr/include/ 1>/dev/null 
lecho $?
message="  Copying Aesimhei.h.....=>./usr/include/ ..."
echo -n $message
cp ./Aesimhei.h      /usr/include/ 1>/dev/null 
lecho $?



#-- Determine if libusb build is required ------------------------------------#
if [ -f /usr/local/lib/libusb.so ] ; then
	echo -en "\nlibusb exists. Re-build required  [y/n] : "
	read resp
else
	resp=Y
fi

if [ "$resp" = "y" ] || [ "$resp" = "Y" ] ; then
	message="(Re)building libusb ..."
	echo -n $message
	cd PayLink
	tar -zxf libusb-0.1.12.tar.gz
	cd libusb-0.1.12
	sh ./configure 1>/dev/null
	if [ "$?" = "0" ] ; then
		make 1>/dev/null
		if [ "$?" = "0" ] ; then
			make install 1>/dev/null 2>&1
			lecho $?
		else
			echo "libusb - Install Error"
			exit 1
		fi
	else
		echo "libusb - Build Error"
		exit 1
	fi
	cd $pd
fi

#-- Determine if libftdi build is required -----------------------------------#
if [ -f /usr/local/lib/libftdi.so ] ; then
	echo -en "\nlibftdi exists. Re-build required  [y/n] : "
	read resp
else
	resp=Y
fi

if [ "$resp" = "y" ] || [ "$resp" = "Y" ] ; then
	message="(Re)building libftdi ..."
	echo -n $message
	cd PayLink
	tar -zxf libftdi-0.17.tar.gz
	cd libftdi-0.17
	sh ./configure 1>/dev/null
	if [ "$?" = "0" ] ; then
		make 1>/dev/null 2>&1
		if [ "$?" = "0" ] ; then
			make install 1>/dev/null 2>&1
			lecho $?
		else
			echo "libftdi - Install Error"
			exit 1
		fi
	else
		echo "libftdi - Build Error"
		exit 1
	fi
	cd $pd
fi




#-- Build AES Access Shared Library ------------------------------------------#
message="Building AES Access Shared Library (libaes_access.so) ..."
echo -n $message
cd PayLink/AccessDLL
make clean 1>/dev/null
make 1>/dev/null
if [ "$?" = "0" ] ; then
    make install 1>/dev/null
fi
lecho $?

cd $pd


#-- Build AES Driver Executable ---------------------------------------------#
message="Building AES Driver Executable (AESCDriver) ..."
echo -n $message
cd PayLink/USB\ Driver/
make clean 1>/dev/null
make 1>/dev/null
if [ "$?" = "0" ] ; then
    make install 1>/dev/null
fi
lecho $?

message="Copying (showtraf command) ..."
echo -n $message
cp ./showtraf.sh /usr/local/bin/showtraf.sh 1>/dev/null 
lecho $?

chmod 6775 /usr/local/bin/showtraf.sh 1>/dev/null 

cd $pd

#-- Build Java Interface ---------------------------------------------#
message="Building Java Interface ..."
echo -n $message
cd PayLink/Java/
./build.sh 1>/dev/null
if [ "$?" = "0" ] ; then
    make install 1>/dev/null
fi
lecho $?

cd $pd


#-- Build AES Reprogrammer Executable ---------------------------------------------#
message="Building AES Reprogrammer Executable (USBProgram) ..."
echo -n $message
cd PayLink/LinuxUSBProgrammer/
make clean 1>/dev/null
make 1>/dev/null
if [ "$?" = "0" ] ; then
    make install 1>/dev/null
fi
lecho $?

cd $pd

echo ""
